package org.example;


import java.util.ArrayList;
import java.util.List;

public class Aluno {
    String nome;
    private int registroAcademico;
    private Professor professor;//Criação da variavel do tipo professor

    List<Professor> professores;

    public Aluno(String nome, int registroAcademico) {
        this.nome = nome;
        this.registroAcademico = registroAcademico;
        this.professores = new ArrayList<>();//contrutor para startar a lista

    }

    public void cadastrarProfessor(Professor prof){
        professores.add(prof);

    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getRegistroAcademico() {
        return registroAcademico;
    }

    public void setRegistroAcademico(int registroAcademico) {
        this.registroAcademico = registroAcademico;
    }

    public Professor getProfessor() {
        return professor;
    }

    public void setProfessor(Professor professor) {
        this.professor = professor;
    }

    public List<Professor> getProfessores() {
        return professores;
    }

    public void setProfessores(List<Professor> professores) {
        this.professores = professores;
    }
}
