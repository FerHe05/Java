package org.example;

import java.util.ArrayList;
import java.util.List;

public class Professor {

    private String nome;
    List<Aluno> alunos;
    public Professor(String nome, int registro) {
        this.nome = nome;
        this.registro = registro;
        this.alunos = new ArrayList<>();
    }

    private int registro;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public List<Aluno> getAlunos() {
        return alunos;
    }

    public void setAlunos(List<Aluno> alunos) {
        this.alunos = alunos;
    }

    public int getRegistro() {
        return registro;
    }

    public void setRegistro(int registro) {
        this.registro = registro;
    }

    public Aluno getAluno() {
        return aluno;
    }

    public void setAluno(Aluno aluno) {
        this.aluno = aluno;
    }

    public void addAluno(Aluno al){
        alunos.add(al);
    }
    Aluno aluno;


}
