package org.example;

public class Studeo {
    public static void main(String[] args) {
        Aluno julia = new Aluno("Julia", 123);
        Aluno tatao = new Aluno("Tavaos", 111);
        Professor messias = new Professor("Messias", 12345);
        Professor ferlini = new Professor("Ferlini", 123456);
        Professor agostinho = new Professor("Agostinho", 1234214156);
        Professor jota = new Professor("Jota", 12341456);


        julia.cadastrarProfessor(messias);
        julia.cadastrarProfessor(ferlini);
        julia.cadastrarProfessor(agostinho);
        julia.cadastrarProfessor(jota);

        messias.addAluno(tatao);
        System.out.println("Alunos do Messias: " + messias.getAlunos().get(0).getNome());

        System.out.println("Qual o registro A = " + julia.getRegistroAcademico());
        System.out.println("Quais professores da Julia= " + julia.getProfessores().get(0).getNome());
        System.out.println("Quais professores da Julia= " + julia.getProfessores().get(1).getNome());

        for (int i = 0; i < julia.getProfessores().size(); i++){
            System.out.println("Os nomes dos professores são: " + julia.getProfessores().get(i).getNome());
        }

    }
}
