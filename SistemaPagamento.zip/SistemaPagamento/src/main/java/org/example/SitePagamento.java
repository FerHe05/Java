package org.example;
public class SitePagamento {
    public static void main(String[] args) {
        Pagamento pgPix = new Pix();

        pgPix.processarPagamento(100);

        Pagamento pgCartao = new CartaoCredito();

        pgCartao.processarPagamento(49.90);

        processar(pgPix, 1000);//polimorfismo
        processar(pgCartao, 1023.42);//polimorfismo

    }

    //polimorfismo
    public static void processar(Pagamento pg, double valor){
        pg.processarPagamento(valor);
    }
}
