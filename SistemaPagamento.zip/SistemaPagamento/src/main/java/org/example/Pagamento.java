package org.example;

interface Pagamento {
    //metodos necessarios para implementação

    void processarPagamento(double valor);

}
