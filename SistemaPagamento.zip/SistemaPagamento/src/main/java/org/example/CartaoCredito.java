package org.example;

public class CartaoCredito implements Pagamento{

    @Override
    public void processarPagamento(double valor) {
        System.out.println("Processamento do valor " + valor + " no cartao de credito");
    }
}


