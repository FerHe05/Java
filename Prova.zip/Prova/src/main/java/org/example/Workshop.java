package org.example;

public class Workshop extends Evento {
    private int participantesAtual;

    public Workshop(String nome, int maxParticipantes, String local) {
        super(nome, maxParticipantes, local);
        this.participantesAtual = 0;
    }

    @Override
    public boolean inscreverParticipante(String participante) {
        if (participantesAtual < getMaxParticipantes()) {
            participantesAtual++;
            System.out.println("Participante " + participante + " inscrito no workshop " + getNome());
            return true;
        } else {
            System.out.println("Workshop " + getNome() + " já está cheio.");
            return false;
        }
    }
}

