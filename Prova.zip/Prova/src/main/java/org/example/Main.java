package org.example;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        Workshop workshop = new Workshop("Workshop de Java", 30, "Sala 101");
        Reuniao reuniao = new Reuniao("Reunião de Estratégia", 10, "Sala 102", true, "1234");
        EventoCorporativo eventoCorporativo = new EventoCorporativo("Lançamento de Produto", 50, "Auditório");

        workshop.inscreverParticipante("Alice");
        reuniao.inscreverParticipante("Bob");
        eventoCorporativo.inscreverParticipante("Carlos");
    }
}