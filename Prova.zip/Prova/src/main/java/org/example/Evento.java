package org.example;

import java.util.List;
import java.util.ArrayList;



    public abstract class Evento {
        private String nome;
        private int maxParticipantes;
        private String local;

        public Evento(String nome, int maxParticipantes, String local) {
            this.nome = nome;
            this.maxParticipantes = maxParticipantes;
            this.local = local;
        }

        // Métodos de acesso
        public String getNome() {
            return nome;
        }

        public int getMaxParticipantes() {
            return maxParticipantes;
        }

        public String getLocal() {
            return local;
        }

        // Método abstrato para inscrição no evento
        public abstract boolean inscreverParticipante(String participante);
    }

