package org.example;

public class EventoCorporativo extends Evento {
    public EventoCorporativo(String nome, int maxParticipantes, String local) {
        super(nome, maxParticipantes, local);
    }

    @Override
    public boolean inscreverParticipante(String participante) {
        System.out.println("Participante " + participante + " inscrito no evento corporativo " + getNome());
        return true;
    }
}