package org.example;
    public class Reuniao extends Evento {
        private boolean isPrivada;
        private String senhaAcesso;

        public Reuniao(String nome, int maxParticipantes, String local, boolean isPrivada, String senhaAcesso) {
            super(nome, maxParticipantes, local);
            this.isPrivada = isPrivada;
            this.senhaAcesso = senhaAcesso;
        }

        @Override
        public boolean inscreverParticipante(String participante) {
            if (isPrivada) {
                System.out.println("Acesso restrito por senha.");
                return false;
            } else {
                System.out.println("Participante " + participante + " inscrito na reunião " + getNome());
                return true;
            }
        }
    }

