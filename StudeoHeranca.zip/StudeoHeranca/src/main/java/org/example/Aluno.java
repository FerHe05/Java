package org.example;

import java.util.ArrayList;
import java.util.List;

public class Aluno extends Pessoa {//extends (herança)

    List<Professor> professores;//Unico atributo exclusivo
    public Aluno(String nome, int registro) {
        super(nome, registro);
        this.professores = new ArrayList<>();
    }

    public List<Professor> getProfessores() {
        return professores;
    }
    public void cadastrarProfessor(Professor prof){
        professores.add(prof);
    }


}
