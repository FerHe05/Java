package org.example;

public class Studeo {
    public static void main(String[] args) {
        Aluno julia = new Aluno("Julia", 123);
        Professor joao = new Professor("Joao", 1234);

   Pessoa pedro = new Professor("Pedro", 12314);

   System.out.println("Professor: " + pedro.getNome());
    }
}
